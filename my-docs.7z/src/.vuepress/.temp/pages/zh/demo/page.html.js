export const data = JSON.parse("{\"key\":\"v-62ced1a6\",\"path\":\"/zh/demo/page.html\",\"title\":\"页面配置\",\"lang\":\"en-US\",\"frontmatter\":{\"title\":\"页面配置\",\"icon\":\"page\",\"order\":1,\"author\":\"Ms.Hope\",\"date\":\"2020-01-01T00:00:00.000Z\",\"category\":[\"使用指南\"],\"tag\":[\"页面配置\",\"使用指南\"],\"sticky\":true,\"star\":true,\"footer\":\"这是测试显示的页脚\",\"copyright\":\"无版权\",\"description\":\"more 注释之前的内容被视为文章摘要。 页面信息 你可以在 Markdown 的 Frontmatter 中设置页面信息。 作者设置为 Ms.Hope。; 写作日期为 2020 年 1 月 1 日; 分类为 “使用指南”; 标签为 “页面配置” 和 “使用指南”; 页面内容 你可以自由在这里书写你的 Markdown。 你可以将图片和 Markdow...\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/zh/demo/page.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Docs Demo\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"页面配置\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"more 注释之前的内容被视为文章摘要。 页面信息 你可以在 Markdown 的 Frontmatter 中设置页面信息。 作者设置为 Ms.Hope。; 写作日期为 2020 年 1 月 1 日; 分类为 “使用指南”; 标签为 “页面配置” 和 “使用指南”; 页面内容 你可以自由在这里书写你的 Markdown。 你可以将图片和 Markdow...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"en-US\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"Ms.Hope\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"页面配置\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"使用指南\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2020-01-01T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"页面配置\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2020-01-01T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"Ms.Hope\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"页面信息\",\"slug\":\"页面信息\",\"link\":\"#页面信息\",\"children\":[]},{\"level\":2,\"title\":\"页面内容\",\"slug\":\"页面内容\",\"link\":\"#页面内容\",\"children\":[]},{\"level\":2,\"title\":\"页面结构\",\"slug\":\"页面结构\",\"link\":\"#页面结构\",\"children\":[]}],\"readingTime\":{\"minutes\":1.43,\"words\":429},\"filePathRelative\":\"zh/demo/page.md\",\"localizedDate\":\"January 1, 2020\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
