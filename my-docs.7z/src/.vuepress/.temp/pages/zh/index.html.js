export const data = JSON.parse("{\"key\":\"v-2d0ad528\",\"path\":\"/zh/\",\"title\":\"项目主页\",\"lang\":\"en-US\",\"frontmatter\":{\"home\":true,\"icon\":\"home\",\"title\":\"项目主页\",\"heroImage\":\"/logo.svg\",\"heroText\":\"AnWen's Docs\",\"tagline\":\"安稳个人使用的一些项目自留地。\",\"actions\":[{\"text\":\"点击这里准备愉快的开始使用吧 💡\",\"link\":\"/zh/demo/\",\"type\":\"primary\"}],\"features\":[{\"title\":\"Markdown 增强\",\"icon\":\"markdown\",\"details\":\"新增文字对齐12、上下角标、脚注、标记、任务列表、数学公式、流程图、图表与幻灯片支持\",\"link\":\"https://theme-hope.vuejs.press/zh/guide/markdown/\"},{\"title\":\"幻灯片页面\",\"icon\":\"slides\",\"details\":\"添加幻灯片页面以显示你喜欢的内容\",\"link\":\"https://theme-hope.vuejs.press/zh/guide/layout/slides.html\"},{\"title\":\"布局增强\",\"icon\":\"layout\",\"details\":\"添加路径导航、页脚、改进的导航栏、改进的页面导航等。\",\"link\":\"https://theme-hope.vuejs.press/zh/guide/layout/\"}],\"copyright\":false,\"footer\":\"使用 <a href=\\\"https://theme-hope.vuejs.press/\\\" target=\\\"_blank\\\">VuePress Theme Hope</a> 主题 | MIT 协议, 版权所有 © 2019-present Mr.Hope\",\"description\":\"这是项目主页的案例。你可以在这里放置你的主体内容。 想要使用此布局，你需要在页面 front matter 中设置 home: true。 配置项的相关说明详见 项目主页配置 (https://theme-hope.vuejs.press/zh/guide/layout/home/)。\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://vuepress-theme-hope-docs-demo.netlify.app/zh/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"Docs Demo\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"项目主页\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"这是项目主页的案例。你可以在这里放置你的主体内容。 想要使用此布局，你需要在页面 front matter 中设置 home: true。 配置项的相关说明详见 项目主页配置 (https://theme-hope.vuejs.press/zh/guide/layout/home/)。\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"en-US\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"Mr.Hope\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"项目主页\\\",\\\"description\\\":\\\"这是项目主页的案例。你可以在这里放置你的主体内容。 想要使用此布局，你需要在页面 front matter 中设置 home: true。 配置项的相关说明详见 项目主页配置 (https://theme-hope.vuejs.press/zh/guide/layout/home/)。\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":2.34,\"words\":702},\"filePathRelative\":\"zh/README.md\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
