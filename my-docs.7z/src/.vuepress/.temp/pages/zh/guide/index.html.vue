<template><div><h2 id="功能亮点" tabindex="-1"><a class="header-anchor" href="#功能亮点" aria-hidden="true">#</a> 功能亮点</h2>
<h3 id="bar" tabindex="-1"><a class="header-anchor" href="#bar" aria-hidden="true">#</a> Bar</h3>
<ul>
<li><RouterLink to="/zh/guide/bar/baz.html">baz</RouterLink></li>
<li>...</li>
</ul>
<h3 id="foo" tabindex="-1"><a class="header-anchor" href="#foo" aria-hidden="true">#</a> Foo</h3>
<ul>
<li><RouterLink to="/zh/guide/foo/ray.html">ray</RouterLink></li>
<li>...</li>
</ul>
</div></template>


