<template><div><h2 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍" aria-hidden="true">#</a> 介绍</h2>
<p>我们支持 bar 功能，...</p>
<h2 id="详情" tabindex="-1"><a class="header-anchor" href="#详情" aria-hidden="true">#</a> 详情</h2>
<ul>
<li><RouterLink to="/zh/guide/bar/baz.html">baz</RouterLink></li>
<li>...</li>
</ul>
</div></template>


