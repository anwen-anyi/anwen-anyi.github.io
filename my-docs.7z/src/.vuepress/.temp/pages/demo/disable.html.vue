<template><div><p>You can disable some function and layout on the page by setting the Frontmatter of the page.</p>
<!-- more -->
<p>This page is an demo that disables the following features:</p>
<ul>
<li>Navbar</li>
<li>Sidebar</li>
<li>Breadcrumb</li>
<li>Page information</li>
<li>Contributors</li>
<li>Edit link</li>
<li>Update time</li>
<li>Prev/Next link</li>
<li>Comment</li>
<li>Footer</li>
<li>Back to top button</li>
</ul>
</div></template>


