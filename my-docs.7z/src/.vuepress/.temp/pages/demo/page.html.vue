<template><div><p>Content before <code v-pre>more</code> comment is regarded as page excerpt.</p>
<!-- more -->
<h2 id="page-information" tabindex="-1"><a class="header-anchor" href="#page-information" aria-hidden="true">#</a> Page Information</h2>
<p>You can set page information in Markdown’s Frontmatter.</p>
<ul>
<li>The author is Ms.Hope.</li>
<li>The writing date is January 1, 2020</li>
<li>Category is &quot;Guide&quot;</li>
<li>Tags are &quot;Page Config&quot; and &quot;Guide&quot;</li>
</ul>
<h2 id="page-content" tabindex="-1"><a class="header-anchor" href="#page-content" aria-hidden="true">#</a> Page Content</h2>
<p>You are free to write your Markdown here.</p>
<div class="hint-container tip">
<p class="hint-container-title">Assets</p>
<ul>
<li>
<p>You can place images besides your Markdown files, but you should use <strong>relative links</strong> (i.e.: starting with <code v-pre>./</code>) for them.</p>
</li>
<li>
<p>For images in <code v-pre>.vuepress/public</code> directory, please use absolute links (i.e.: starting with <code v-pre>/</code>) for them.</p>
</li>
</ul>
</div>
<p>The theme contains a custom badge:</p>
<blockquote>
<p>A dark blue badge text badge at the end of line. <Badge text="Badge text" color="#242378" /></p>
</blockquote>
<h2 id="page-structure" tabindex="-1"><a class="header-anchor" href="#page-structure" aria-hidden="true">#</a> Page Structure</h2>
<p>This page should contain:</p>
<ul>
<li><a href="https://theme-hope.vuejs.press/guide/layout/breadcrumb.html" target="_blank" rel="noopener noreferrer">BreadCrumb<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/feature/page-info.html" target="_blank" rel="noopener noreferrer">Title and information<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/layout/page.html#header-list" target="_blank" rel="noopener noreferrer">TOC (Table of Contents)<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/feature/meta.html" target="_blank" rel="noopener noreferrer">Meta information including update time and contributors<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/feature/comment.html" target="_blank" rel="noopener noreferrer">Comments<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/layout/navbar.html" target="_blank" rel="noopener noreferrer">Navbar<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/layout/sidebar.html" target="_blank" rel="noopener noreferrer">Sidebar<ExternalLinkIcon/></a></li>
<li><a href="https://theme-hope.vuejs.press/guide/layout/footer.html" target="_blank" rel="noopener noreferrer">Footer<ExternalLinkIcon/></a></li>
<li>Back to top button</li>
</ul>
<p>You can customize them in theme options and page frontmatter.</p>
</div></template>


