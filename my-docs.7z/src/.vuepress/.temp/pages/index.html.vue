<template><div><p>This is an example of a project homepage. You can place your main content here.</p>
<p>To use this layout, you need to set <code v-pre>home: true</code> in the page front matter.</p>
<p>For related descriptions of configuration items, please see <a href="https://theme-hope.vuejs.press/guide/layout/home/" target="_blank" rel="noopener noreferrer">Project HomePage Layout Config<ExternalLinkIcon/></a>.</p>
</div></template>


