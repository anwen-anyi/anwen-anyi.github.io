<template><div><h2 id="highlight-features" tabindex="-1"><a class="header-anchor" href="#highlight-features" aria-hidden="true">#</a> Highlight Features</h2>
<h3 id="bar" tabindex="-1"><a class="header-anchor" href="#bar" aria-hidden="true">#</a> Bar</h3>
<ul>
<li><RouterLink to="/guide/bar/baz.html">baz</RouterLink></li>
<li>...</li>
</ul>
<h3 id="foo" tabindex="-1"><a class="header-anchor" href="#foo" aria-hidden="true">#</a> Foo</h3>
<ul>
<li><RouterLink to="/guide/foo/ray.html">ray</RouterLink></li>
<li>...</li>
</ul>
</div></template>


