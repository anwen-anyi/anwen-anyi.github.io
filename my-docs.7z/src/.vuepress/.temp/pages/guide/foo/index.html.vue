<template><div><h2 id="introduction" tabindex="-1"><a class="header-anchor" href="#introduction" aria-hidden="true">#</a> Introduction</h2>
<p>We support foo feature, ...</p>
<h2 id="details" tabindex="-1"><a class="header-anchor" href="#details" aria-hidden="true">#</a> Details</h2>
<ul>
<li><RouterLink to="/guide/foo/ray.html">ray</RouterLink></li>
<li>...</li>
</ul>
</div></template>


