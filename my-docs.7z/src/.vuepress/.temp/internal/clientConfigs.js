import clientConfig0 from 'C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/sass-palette/load-hope.js'
import clientConfig1 from 'C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/components/config.js'
import clientConfig2 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+@vuepress+plugin-active-header-links@2.0.0-beta.61/node_modules/@vuepress/plugin-active-header-links/lib/client/config.js'
import clientConfig3 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+vuepress-plugin-auto-catalog@2.0.0-beta.200_vuepress@2.0.0-beta.61/node_modules/vuepress-plugin-auto-catalog/lib/client/config.js'
import clientConfig4 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+@vuepress+plugin-external-link-icon@2.0.0-beta.61/node_modules/@vuepress/plugin-external-link-icon/lib/client/config.js'
import clientConfig5 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+@vuepress+plugin-nprogress@2.0.0-beta.61/node_modules/@vuepress/plugin-nprogress/lib/client/config.js'
import clientConfig6 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+@vuepress+plugin-theme-data@2.0.0-beta.61/node_modules/@vuepress/plugin-theme-data/lib/client/config.js'
import clientConfig7 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+vuepress-plugin-comment2@2.0.0-beta.200_vuepress@2.0.0-beta.61/node_modules/vuepress-plugin-comment2/lib/client/config.js'
import clientConfig8 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+vuepress-plugin-copy-code2@2.0.0-beta.200_vuepress@2.0.0-beta.61/node_modules/vuepress-plugin-copy-code2/lib/client/config.js'
import clientConfig9 from 'C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/md-enhance/config.js'
import clientConfig10 from 'C:/Users/安稳/Desktop/git/my-docs/node_modules/.pnpm/registry.npmmirror.com+vuepress-plugin-photo-swipe@2.0.0-beta.200_vuepress@2.0.0-beta.61/node_modules/vuepress-plugin-photo-swipe/lib/client/config.js'
import clientConfig11 from 'C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/theme-hope/config.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
]
