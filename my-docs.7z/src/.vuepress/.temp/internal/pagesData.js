export const pagesData = {
  // path: /
  "v-8daa1a0e": () => import(/* webpackChunkName: "v-8daa1a0e" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/index.html.js").then(({ data }) => data),
  // path: /slides.html
  "v-2e3eac9e": () => import(/* webpackChunkName: "v-2e3eac9e" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/slides.html.js").then(({ data }) => data),
  // path: /demo/disable.html
  "v-4e65ec78": () => import(/* webpackChunkName: "v-4e65ec78" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/demo/disable.html.js").then(({ data }) => data),
  // path: /demo/encrypt.html
  "v-c151bf32": () => import(/* webpackChunkName: "v-c151bf32" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/demo/encrypt.html.js").then(({ data }) => data),
  // path: /demo/markdown.html
  "v-438ffe52": () => import(/* webpackChunkName: "v-438ffe52" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/demo/markdown.html.js").then(({ data }) => data),
  // path: /demo/page.html
  "v-6e19edb7": () => import(/* webpackChunkName: "v-6e19edb7" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/demo/page.html.js").then(({ data }) => data),
  // path: /demo/
  "v-1473bf53": () => import(/* webpackChunkName: "v-1473bf53" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/demo/index.html.js").then(({ data }) => data),
  // path: /guide/
  "v-fffb8e28": () => import(/* webpackChunkName: "v-fffb8e28" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/guide/index.html.js").then(({ data }) => data),
  // path: /zh/
  "v-2d0ad528": () => import(/* webpackChunkName: "v-2d0ad528" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/index.html.js").then(({ data }) => data),
  // path: /zh/slides.html
  "v-269ae70f": () => import(/* webpackChunkName: "v-269ae70f" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/slides.html.js").then(({ data }) => data),
  // path: /guide/bar/baz.html
  "v-177e1f06": () => import(/* webpackChunkName: "v-177e1f06" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/guide/bar/baz.html.js").then(({ data }) => data),
  // path: /guide/bar/
  "v-5d5c2d30": () => import(/* webpackChunkName: "v-5d5c2d30" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/guide/bar/index.html.js").then(({ data }) => data),
  // path: /guide/foo/ray.html
  "v-0b6fc5f8": () => import(/* webpackChunkName: "v-0b6fc5f8" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/guide/foo/ray.html.js").then(({ data }) => data),
  // path: /guide/foo/
  "v-5d5821d6": () => import(/* webpackChunkName: "v-5d5821d6" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/guide/foo/index.html.js").then(({ data }) => data),
  // path: /zh/demo/disable.html
  "v-c1942916": () => import(/* webpackChunkName: "v-c1942916" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/demo/disable.html.js").then(({ data }) => data),
  // path: /zh/demo/encrypt.html
  "v-65c00218": () => import(/* webpackChunkName: "v-65c00218" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/demo/encrypt.html.js").then(({ data }) => data),
  // path: /zh/demo/markdown.html
  "v-36295574": () => import(/* webpackChunkName: "v-36295574" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/demo/markdown.html.js").then(({ data }) => data),
  // path: /zh/demo/page.html
  "v-62ced1a6": () => import(/* webpackChunkName: "v-62ced1a6" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/demo/page.html.js").then(({ data }) => data),
  // path: /zh/demo/
  "v-2b64e284": () => import(/* webpackChunkName: "v-2b64e284" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/demo/index.html.js").then(({ data }) => data),
  // path: /zh/guide/
  "v-47357bdb": () => import(/* webpackChunkName: "v-47357bdb" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/guide/index.html.js").then(({ data }) => data),
  // path: /zh/guide/bar/baz.html
  "v-1e317375": () => import(/* webpackChunkName: "v-1e317375" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/guide/bar/baz.html.js").then(({ data }) => data),
  // path: /zh/guide/bar/
  "v-763c1cd7": () => import(/* webpackChunkName: "v-763c1cd7" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/guide/bar/index.html.js").then(({ data }) => data),
  // path: /zh/guide/foo/ray.html
  "v-00fb7173": () => import(/* webpackChunkName: "v-00fb7173" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/guide/foo/ray.html.js").then(({ data }) => data),
  // path: /zh/guide/foo/
  "v-763e2284": () => import(/* webpackChunkName: "v-763e2284" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/zh/guide/foo/index.html.js").then(({ data }) => data),
  // path: /404.html
  "v-3706649a": () => import(/* webpackChunkName: "v-3706649a" */"C:/Users/安稳/Desktop/git/my-docs/src/.vuepress/.temp/pages/404.html.js").then(({ data }) => data),
}
