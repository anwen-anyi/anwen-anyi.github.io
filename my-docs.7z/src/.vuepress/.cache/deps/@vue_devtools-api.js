import {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
} from "./chunk-IXCVSLRB.js";
export {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
};
//# sourceMappingURL=@vue_devtools-api.js.map
