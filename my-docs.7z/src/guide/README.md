---
title: Guide
icon: creative
---

## Highlight Features

### Bar

- [baz](bar/baz.md)
- ...

### Foo

- [ray](foo/ray.md)
- ...
