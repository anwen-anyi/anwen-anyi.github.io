---
title: Bar feature
icon: creative
---

## Introduction

We support bar feature, ...

## Details

- [baz](baz.md)
- ...
